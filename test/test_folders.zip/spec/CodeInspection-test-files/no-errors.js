function foo() {
    "use strict";
}