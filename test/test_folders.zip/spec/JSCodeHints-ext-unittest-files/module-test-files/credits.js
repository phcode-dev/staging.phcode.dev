/*jslint vars: true, plusplus: true, devel: true, browser: true, nomen: true, indent: 4, maxerr: 50 */
/*global define, $ */
define(function () {
	'use strict';
	return {
		getCredits: function () {
			var credits = "100";
			return credits;
		}
    };
});
