/*jslint vars: true, plusplus: true, devel: true, browser: true, nomen: true, indent: 4, maxerr: 50 */
/*global */

var app = app || {};

(function () {
    'use strict';

    app.d23 = 423;

}());
