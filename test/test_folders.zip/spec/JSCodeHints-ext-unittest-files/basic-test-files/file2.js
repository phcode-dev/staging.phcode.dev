/*jslint vars: true, plusplus: true, devel: true, rhino: true, nomen: true, indent: 4, maxerr: 50 */
/*global crazyGlobal, anotherCrazyGlobal */

var D1 = { propD : 1 },
    D2 = { propD : 2 };

function funE(paramE1, paramE2) {
    'use strict';
    
    var E1 = { propE : 1 },
        E2 = { propE : 2 };

    console.log("a very nice string");
}
