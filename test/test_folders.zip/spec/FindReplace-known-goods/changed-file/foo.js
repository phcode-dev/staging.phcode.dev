/* Test comment */
define(function (require, exports, module) {
    var bar = require("modules/bar"),
        Bar = require("modules/Bar"),
        Baz = require("modules/Baz");
    
    function callbar() {
        
        bar();
        
    }

}
