// Function containing regular expression
function test() {
    return (/\.(eot|otf|ttf|wo)$/i);
}