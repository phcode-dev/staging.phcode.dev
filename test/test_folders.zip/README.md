Overview
========

Unit testing for brackets uses [Jasmine](http://jasmine.github.io/1.3/introduction.html).

Getting started
===============

Running Tests
-------------

Run brackets-app and click "Run Tests" from the menu (debugging and dev tools **not** supported)

Adding New Tests

1. Create a new .js file under spec/
1. Write the test (see spec/Editor-test.js or Jasmine documentation)
1. Edit SpecRunner.html and add the spec .js file in a new script tag

Known Issues
============

None
